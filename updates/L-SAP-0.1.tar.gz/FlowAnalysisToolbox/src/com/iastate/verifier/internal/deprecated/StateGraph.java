package com.iastate.verifier.internal.deprecated;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import com.ensoftcorp.atlas.core.db.graph.GraphElement;
import com.ensoftcorp.atlas.core.xcsg.XCSG;
import com.iastate.verifier.internal.Utils;

public class StateGraph {
	
	private GraphElement function;
	private HashSet<StateNode> nodes;
	private HashSet<StateEdge> edges;
	private HashMap<StateNode, HashSet<StateNode>> childrenMap;
	private HashMap<StateNode, HashSet<StateNode>> parentsMap;
	private StateNode rootNode;
	private List<ArrayList<GraphElement>> paths;

	public StateGraph(GraphElement function) {
		this.function = function;
		this.nodes = new HashSet<StateNode>();
		this.edges = new HashSet<StateEdge>();
		this.childrenMap = new HashMap<StateNode, HashSet<StateNode>>();
		this.parentsMap = new HashMap<StateNode, HashSet<StateNode>>();
		this.paths = new ArrayList<ArrayList<GraphElement>>();
	}
	
	public HashSet<StateNode> getChildNodes(ArrayList<GraphElement> path, StateNode node){
		HashSet<StateNode> nodes = new HashSet<StateNode>();
		for(StateNode n : this.childrenMap.get(node)){
			if(!path.contains(n.getNode()))
				nodes.add(n);
		}
		return nodes;
	}
	
	public HashSet<StateNode> getChildNodes(StateNode node){
		return this.childrenMap.get(node);
	}
	
	public HashSet<StateNode> getParentNodes(StateNode node){
		return this.parentsMap.get(node);
	}
	
	public void addNode(StateNode node){
		if(this.nodes.contains(node))
			return;
		this.nodes.add(node);
		this.childrenMap.put(node, new HashSet<StateNode>());
		this.parentsMap.put(node, new HashSet<StateNode>());
	}
	
	public void addEdge(StateNode from, StateNode to){
		StateEdge edge = new StateEdge(from, to);
		this.addEdge(edge);
	}
	
	public void addEdge(StateEdge edge){
		this.edges.add(edge);
		StateNode from = edge.getFrom();
		StateNode to = edge.getTo();
		HashSet<StateNode> children = this.childrenMap.get(from);
		children.add(to);
		this.childrenMap.put(from, children);
		
		HashSet<StateNode> parents = this.parentsMap.get(to);
		parents.add(from);
		this.parentsMap.put(to, parents);
	}

	public HashSet<StateNode> getNodes() {
		return nodes;
	}
	public void setNodes(HashSet<StateNode> nodes) {
		this.nodes = nodes;
	}
	public HashSet<StateEdge> getEdges() {
		return edges;
	}
	public void setEdges(HashSet<StateEdge> edges) {
		this.edges = edges;
	}
	
	public void setRootNode(StateNode masterEntryNode) {
		this.rootNode = masterEntryNode;
	}
	
	public List<ArrayList<GraphElement>> getPaths() {
		if(paths.isEmpty()){
			traverse(this.rootNode, new ArrayList<GraphElement>());	
		}
		return paths;
	}
	
	/*
	private void traverse(StateNode node, ArrayList<GraphElement> path){
		HashSet<StateNode> children = null;
		
		if(path.contains(node.getNode())){
			if(node.getNode().tags().contains(XCSG.ControlFlowLoopCondition)){
				children = this.getChildNodes(path, node);
			}else{
				Utils.debug(0, ">>>>>>>>>>>> " + function.attr().get(XCSG.name) + "");
				Utils.debug(0, ">>>>>>>>>>>> " + node.getNode().attr().get(XCSG.name) + "");
			}
		}else{
			children = this.getChildNodes(node);
		}
		
		//children = this.getChildNodes(node);
		path.add(node.getNode());
		if(children.size() == 0){
			paths.add(path);
		}else{
			for(StateNode child : children){
				ArrayList<GraphElement> newPath = new ArrayList<GraphElement>(path);
				traverse(child, newPath);
			}
		}
	}*/
	
	private void traverse(StateNode node, ArrayList<GraphElement> path){
		path.add(node.getNode());
		HashSet<StateNode> children = this.getChildNodes(node);
		if(children.size() == 0){
			paths.add(new ArrayList<GraphElement>(path));
		}else{
			for(StateNode child : children){
				ArrayList<GraphElement> newPath = new ArrayList<GraphElement>(path);
				traverse(child, newPath);
			}
		}
	}
	
	@Override
	public String toString() {
		StringBuilder result = new StringBuilder();
		result.append("#######################################################################\n");
		result.append("StateGraph for [" + this.function.attr().get(XCSG.name) + "]\n");
		result.append("Number Of Paths: [" + this.paths.size() + "]\n");
		for(ArrayList<GraphElement> path : this.paths){
			for(int i = 0; i < path.size(); i++){
				result.append(Utils.toString(path.get(i)));
				if(i < path.size() - 1){
					result.append(" >>> ");
				}
			}
			result.append("\n");
		}
		result.append("#######################################################################\n");
		return result.toString();
	}
}
