package com.iastate.verifier.internal;

public class CFGDisconnectedException extends Exception {
	
	private static final long serialVersionUID = -5723585054892956361L;
	
	public CFGDisconnectedException(String string) {
		super(string);
	}
}
