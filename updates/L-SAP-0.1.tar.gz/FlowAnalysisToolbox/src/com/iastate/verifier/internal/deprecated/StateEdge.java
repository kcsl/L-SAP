package com.iastate.verifier.internal.deprecated;

public class StateEdge {

	private StateNode from;
	private StateNode to;
	private boolean attribute;
	private boolean conditionValue;
	
	public StateEdge(StateNode from, StateNode to) {
		this.setFrom(from);
		this.setTo(to);
	}

	public StateNode getFrom() {
		return from;
	}

	public void setFrom(StateNode from) {
		this.from = from;
	}

	public StateNode getTo() {
		return to;
	}

	public void setTo(StateNode to) {
		this.to = to;
	}

	public boolean isAttribute() {
		return attribute;
	}

	public void setAttribute(boolean attribute) {
		this.attribute = attribute;
	}

	public boolean isConditionValue() {
		return conditionValue;
	}

	public void setConditionValue(boolean conditionValue) {
		this.conditionValue = conditionValue;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (attribute ? 1231 : 1237);
		result = prime * result + (conditionValue ? 1231 : 1237);
		result = prime * result + ((from == null) ? 0 : from.hashCode());
		result = prime * result + ((to == null) ? 0 : to.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		StateEdge other = (StateEdge) obj;
		if (attribute != other.attribute)
			return false;
		if (conditionValue != other.conditionValue)
			return false;
		if (from == null) {
			if (other.from != null)
				return false;
		} else if (!from.equals(other.from))
			return false;
		if (to == null) {
			if (other.to != null)
				return false;
		} else if (!to.equals(other.to))
			return false;
		return true;
	}
}
