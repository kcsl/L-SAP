package com.iastate.verifier.internal.deprecated;

import static com.ensoftcorp.atlas.java.core.script.Common.universe;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import atlas.c.scripts.Queries;

import com.ensoftcorp.atlas.core.db.graph.Graph;
import com.ensoftcorp.atlas.core.db.graph.GraphElement;
import com.ensoftcorp.atlas.core.db.set.AtlasSet;
import com.ensoftcorp.atlas.core.xcsg.XCSG;
import com.ensoftcorp.atlas.java.core.query.Q;
import com.ensoftcorp.atlas.java.core.script.Common;
import com.iastate.verifier.internal.Utils;
import com.iastate.verifier.main.FunctionSummary;

public class EnhancedFunctionSummaryGenerator {
	
	private Graph flowGraph;
    private GraphElement currentFunction;
    private GraphElement entryNode;
    private GraphElement exitNode;
    private ArrayList<ArrayList<GraphElement>> allPaths;
    private HashSet<ArrayList<GraphElement>> completePaths;
    private ArrayList<ArrayList<GraphElement>> inCompletePaths;
	private AtlasSet<GraphElement> functionChildren;
	private HashMap<GraphElement, Boolean> nodeVisitingStatusMap;
	
	public EnhancedFunctionSummaryGenerator(GraphElement function, Graph flowGraph, AtlasSet<GraphElement> children) {
		this.currentFunction = function;
		this.flowGraph = flowGraph;
    	this.entryNode = this.flowGraph.nodes().filter(XCSG.name, Queries.EVENT_FLOW_ENTRY_NODE).getFirst();
    	this.exitNode = this.flowGraph.nodes().filter(XCSG.name, Queries.EVENT_FLOW_EXIT_NODE).getFirst();
    	this.allPaths = new ArrayList<ArrayList<GraphElement>>();
    	this.completePaths = new HashSet<ArrayList<GraphElement>>();
    	this.inCompletePaths = new ArrayList<ArrayList<GraphElement>>();
    	this.functionChildren = children;
    	this.nodeVisitingStatusMap = new HashMap<GraphElement, Boolean>();
	}
	
	public FunctionSummary run(List<Q> events){
		FunctionSummary functionSummary = new FunctionSummary(this.currentFunction, flowGraph, events);
		
		HashMap<GraphElement, GraphElement> callEventsFunctionsMap = new HashMap<GraphElement, GraphElement>();
		
		AtlasSet<GraphElement> nodes = events.get(2).eval().nodes();
		//Utils.debug(0, "Called Functions Count:" + this.functionChildren.size());
		//Utils.debug(0, "Called Functions Count:" + Utils.toString(this.functionChildren));
		for(GraphElement node : nodes){
			for(GraphElement calledFunction : this.functionChildren){
				Q callSitesQuery = universe().edgesTaggedWithAll(XCSG.Contains).forward(Common.toQ(Common.toGraph(node))).nodesTaggedWithAll(XCSG.CallSite);
				String calledFunctionName = (String) calledFunction.attr().get(XCSG.name);
				AtlasSet<GraphElement> callSites = callSitesQuery.eval().nodes();
				for(GraphElement callSite : callSites){
					String name = (String) callSite.attr().get(XCSG.name);
					if(name.contains(calledFunctionName + "(")){
						//Utils.debug(0, "Sussson:" + Utils.toString(node) + "\t" + Utils.toString(calledFunction));
						callEventsFunctionsMap.put(node, calledFunction);
					}
				}
			}
		}
    	
    	this.traverse();
    	
    	functionSummary.setEntryNode(this.entryNode);
    	functionSummary.setExitNode(this.exitNode);
    	functionSummary.setPaths(this.allPaths);
    	functionSummary.setCallEventsFunctionsMap(callEventsFunctionsMap);
        return functionSummary;
	}
	
	public void traverse()
    {
    	this.traverse(this.entryNode, new ArrayList<GraphElement>());
    	
    	/*
    	int count = 0;
    	for(ArrayList<GraphElement> path : this.completePaths){
    		Utils.debug(0, "Complete Path[" + (++count) + "]:" + Utils.toString(path));
    	}
    	
    	count = 0;
    	for(ArrayList<GraphElement> path : this.inCompletePaths){
    		Utils.debug(0, "Incomplete Path[" + (++count) + "]:" + Utils.toString(path));
    	}
    	*/
    	this.fixInCompletePaths();
    }
	
	private void traverse(GraphElement node, ArrayList<GraphElement> path){
		path.add(node);
		this.nodeVisitingStatusMap.put(node, true);
		
		AtlasSet<GraphElement> children = Utils.getChildNodes(this.flowGraph, node);
		if(children.isEmpty()){
			this.completePaths.add(path);
		}else{
			for(GraphElement child : children){
				if(this.isNodeCompletelyVisited(child) && !child.equals(this.exitNode)){
					ArrayList<GraphElement> newPath = new ArrayList<GraphElement>(path);
					newPath.add(child);
					this.inCompletePaths.add(newPath);
				}else{
					traverse(child, new ArrayList<GraphElement>(path));
				}
			}
		}
	}
	
	private void fixInCompletePaths(){
    	HashMap<GraphElement, ArrayList<ArrayList<GraphElement>>> nodeSuffixPathsMap = new HashMap<GraphElement, ArrayList<ArrayList<GraphElement>>>();
    	this.buildNodeSuffixPathsMap(nodeSuffixPathsMap, this.completePaths);
    	
    	
    	
    	for(ArrayList<GraphElement> path : this.inCompletePaths){
    		ArrayList<ArrayList<GraphElement>> newCompletedPaths = new ArrayList<ArrayList<GraphElement>>();
    		GraphElement lastNodeInPath = path.get(path.size() - 1);
    		AtlasSet<GraphElement> children = Utils.getChildNodes(this.flowGraph, lastNodeInPath);
    		for(GraphElement child : children){
    			//Utils.debug(0, "Current Path:" + Utils.toString(path));
				//Utils.debug(0, "Last Node In Path:" + Utils.toString(child));
				if(child.equals(this.exitNode)){
					ArrayList<GraphElement> newPath = new ArrayList<GraphElement>(path);
					newPath.add(child);
					newCompletedPaths.add(newPath);					
					this.updateNodeSuffixPathsMap(nodeSuffixPathsMap, newPath);
				}else{
					ArrayList<ArrayList<GraphElement>> suffixPaths = nodeSuffixPathsMap.get(child);
					for(List<GraphElement> suffixPath : suffixPaths){
						ArrayList<GraphElement> newPath = new ArrayList<GraphElement>(path);
						newPath.add(child);
			    		newPath.addAll(suffixPath);
			    		newCompletedPaths.add(newPath);
					}
					for(ArrayList<GraphElement> newPath : newCompletedPaths){
						this.updateNodeSuffixPathsMap(nodeSuffixPathsMap, newPath);
					}
				}
    		}
    		this.completePaths.addAll(newCompletedPaths);
    	}
    	
    	
    	
    	
    	for(ArrayList<GraphElement> path : this.completePaths){
    		this.allPaths.add(path);
    	}
    	this.completePaths.clear();
    	this.inCompletePaths.clear();
	}
	
	private void buildNodeSuffixPathsMap(HashMap<GraphElement, ArrayList<ArrayList<GraphElement>>> nodeSuffixPathsMap, HashSet<ArrayList<GraphElement>> paths){
		for(ArrayList<GraphElement> path : paths){
			for(int i = 0; i < path.size(); i++){
				GraphElement node = path.get(i);
				
				ArrayList<GraphElement> suffixPath = new ArrayList<GraphElement>();
    			for(int j = i+1; j < path.size(); j++){
    				suffixPath.add(path.get(j));
    			}
				
    			if(!suffixPath.isEmpty()){
    				ArrayList<ArrayList<GraphElement>> nodeSuffixPaths = new ArrayList<ArrayList<GraphElement>>();
					if(nodeSuffixPathsMap.containsKey(node)){
						nodeSuffixPaths = nodeSuffixPathsMap.get(node);
					}
					nodeSuffixPaths.add(suffixPath);
					nodeSuffixPathsMap.put(node, nodeSuffixPaths);
    			}
			}
		}
	}
	
	private void updateNodeSuffixPathsMap(HashMap<GraphElement, ArrayList<ArrayList<GraphElement>>> nodeSuffixPathsMap, ArrayList<GraphElement> path){
		for(int i = 0; i < path.size(); i++){
			GraphElement node = path.get(i);
			
			ArrayList<GraphElement> suffixPath = new ArrayList<GraphElement>();
			for(int j = i+1; j < path.size(); j++){
				suffixPath.add(path.get(j));
			}
			
			if(!suffixPath.isEmpty()){
				ArrayList<ArrayList<GraphElement>> nodeSuffixPaths = new ArrayList<ArrayList<GraphElement>>();
				if(nodeSuffixPathsMap.containsKey(node)){
					nodeSuffixPaths = nodeSuffixPathsMap.get(node);
				}
				nodeSuffixPaths.add(suffixPath);
				nodeSuffixPathsMap.put(node, nodeSuffixPaths);
			}
		}
	}
    
    private boolean isNodeCompletelyVisited(GraphElement node){
    	AtlasSet<GraphElement> children = Utils.getChildNodes(this.flowGraph, node);
    	for(GraphElement child : children){
    		if(this.nodeVisitingStatusMap.get(child) == null || !this.nodeVisitingStatusMap.get(child)){
    			return false;
    		}
    	}
    	return true;
    }
}
