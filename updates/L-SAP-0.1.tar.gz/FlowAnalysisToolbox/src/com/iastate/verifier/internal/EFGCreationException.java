package com.iastate.verifier.internal;

public class EFGCreationException extends Exception {

	private static final long serialVersionUID = -8873259937325323087L;

	public EFGCreationException(String string, NullPointerException e) {
		super(string, e);
	}

}
