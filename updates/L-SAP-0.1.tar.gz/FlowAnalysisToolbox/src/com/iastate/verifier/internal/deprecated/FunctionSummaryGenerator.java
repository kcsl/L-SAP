package com.iastate.verifier.internal.deprecated;

import static com.ensoftcorp.atlas.java.core.script.Common.universe;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import atlas.c.scripts.Queries;

import com.ensoftcorp.atlas.core.db.graph.Graph;
import com.ensoftcorp.atlas.core.db.graph.GraphElement;
import com.ensoftcorp.atlas.core.db.set.AtlasHashSet;
import com.ensoftcorp.atlas.core.db.set.AtlasSet;
import com.ensoftcorp.atlas.core.xcsg.XCSG;
import com.ensoftcorp.atlas.java.core.query.Q;
import com.ensoftcorp.atlas.java.core.script.Common;
import com.iastate.atlas.scripts.LinuxScripts;
import com.iastate.verifier.internal.PathStatus;
import com.iastate.verifier.internal.Utils;
import com.iastate.verifier.main.FunctionSummary;

public class FunctionSummaryGenerator {

	private HashMap<GraphElement, HashMap<String, Object>> childrenFunctionSummaries;
	
	private HashMap<String, Object> functionSummary;
	
	private Graph flowGraph;
	
	private AtlasSet<GraphElement> lEventNodes;
	
	private AtlasSet<GraphElement> uEventNodes;
	
	private HashMap<GraphElement, Integer> pathToS;
	private HashMap<GraphElement, Integer> pathBackS;
	private HashMap<GraphElement, AtlasSet<GraphElement>> pathToL;
	private HashMap<GraphElement, AtlasSet<GraphElement>> pathBackL;
	
	private HashMap<GraphElement, List<ArrayList<GraphElement>>> nodePathsMap;
    
    private GraphElement currentFunction;
    
    private GraphElement entryNode;
    private GraphElement exitNode;
    
    private ArrayList<ArrayList<GraphElement>> allPaths = new ArrayList<ArrayList<GraphElement>>();
	
	public FunctionSummaryGenerator(GraphElement function, Graph flowGraph, HashMap<GraphElement, HashMap<String, Object>> summary) {
		this.currentFunction = function;
		this.childrenFunctionSummaries = (HashMap<GraphElement, HashMap<String, Object>>) summary.clone();
		this.flowGraph = flowGraph;
		
        this.pathToS = new HashMap<GraphElement, Integer>();
        this.pathToL = new HashMap<GraphElement, AtlasSet<GraphElement>>();
        
        this.pathBackS = new HashMap<GraphElement, Integer>();
        this.pathBackL = new HashMap<GraphElement, AtlasSet<GraphElement>>();
        this.nodePathsMap = new HashMap<GraphElement, List<ArrayList<GraphElement>>>();
	}
	
	public FunctionSummary run(List<Q> events){
		FunctionSummary functionSummary = new FunctionSummary(this.currentFunction, flowGraph, events);
		
		this.lEventNodes = events.get(0).eval().nodes();
		this.uEventNodes = events.get(1).eval().nodes();
		
		HashMap<GraphElement, GraphElement> callEventsFunctionsMap = new HashMap<GraphElement, GraphElement>();
		
		HashMap<GraphElement, HashMap<String, Object>> summary = new HashMap<GraphElement, HashMap<String,Object>>();
		AtlasSet<GraphElement> nodes = events.get(2).eval().nodes();
		for(GraphElement node : nodes){
			for(GraphElement calledFunction : this.childrenFunctionSummaries.keySet()){
				Q callSitesQuery = universe().edgesTaggedWithAll(XCSG.Contains).forward(Common.toQ(Common.toGraph(node))).nodesTaggedWithAll(XCSG.CallSite);
				String calledFunctionName = (String) calledFunction.attr().get(XCSG.name);
				AtlasSet<GraphElement> callSites = callSitesQuery.eval().nodes();
				for(GraphElement callSite : callSites){
					String name = (String) callSite.attr().get(XCSG.name);
					if(name.contains(calledFunctionName + "(")){
						summary.put(node, this.childrenFunctionSummaries.get(calledFunction));
						callEventsFunctionsMap.put(node, calledFunction);
					}
				}
			}
		}
		this.childrenFunctionSummaries.clear();
		this.childrenFunctionSummaries = summary;
		
    	//this.duplicateMultipleStatusFunctions();
    	
    	this.verifyCFG();
    	functionSummary.setEntryNode(this.entryNode);
    	functionSummary.setExitNode(this.exitNode);
    	functionSummary.setPaths(allPaths);
    	functionSummary.setCallEventsFunctionsMap(callEventsFunctionsMap);
        return functionSummary;
	}
	
    @SuppressWarnings("unchecked")
	public void verifyCFG()
    {
    	Utils.debug(0, "Currently traversing function: " + this.currentFunction.attr().get(XCSG.name));
    	this.entryNode = this.flowGraph.nodes().filter(XCSG.name, Queries.EVENT_FLOW_ENTRY_NODE).getFirst();
    	this.exitNode = this.flowGraph.nodes().filter(XCSG.name, Queries.EVENT_FLOW_EXIT_NODE).getFirst();
    	
    	for(GraphElement node : this.flowGraph.nodes()){
    		if(node.equals(this.entryNode) || node.equals(this.exitNode)){
    			continue;
    		}
    		this.nodePathsMap.put(node, new ArrayList<ArrayList<GraphElement>>());
    	}
    	
    	Object [] returns = traverseFlowGraph(this.entryNode, PathStatus.THROUGH, new AtlasHashSet<GraphElement>(), new ArrayList<GraphElement>());
    	
    	int rets = (Integer) returns[0];
    	AtlasSet<GraphElement> retl = (AtlasSet<GraphElement>)returns[1];

    	this.functionSummary = new HashMap<String, Object>();
    	this.functionSummary.put("rets", rets);
    	this.functionSummary.put("retl", retl);
    	this.functionSummary.put("outs", this.pathToS.get(this.exitNode));
    	this.functionSummary.put("outl", this.pathToL.get(this.exitNode));
    }
    
    @SuppressWarnings("unchecked")
	public Object[] traverseFlowGraph(GraphElement node, int pathStatus, AtlasSet<GraphElement> nodeInstances, ArrayList<GraphElement> path){
    	path.add(node);
    	if(node.equals(this.exitNode)){
    		allPaths.add(path);
    	}
    	if(!node.equals(this.entryNode) && !node.equals(this.exitNode)){
    		//Utils.debug(0, "############ TRAVERSAL #############:" + Utils.toString(node));
        	List<ArrayList<GraphElement>> newPaths = this.nodePathsMap.get(node);
        	newPaths.add(new ArrayList<GraphElement>(path));
        	this.nodePathsMap.put(node, newPaths);
    	}
    	//if(node.equals(this.entryNode)){
    	//	Utils.debug(0, "############ TRAVERSAL #############:Entry");
    	//}
    	//if(node.equals(this.exitNode)){
    	//	Utils.debug(0, "############ TRAVERSAL #############:Exit");
    	//}
    		
    	int rets = 0, outs;
    	AtlasSet<GraphElement> retl = new AtlasHashSet<GraphElement>();
    	AtlasSet<GraphElement> outl = new AtlasHashSet<GraphElement>();
    	
    	int childrens, childs;
    	AtlasSet<GraphElement> childrenl = new AtlasHashSet<GraphElement>();
    	AtlasSet<GraphElement> childl = new AtlasHashSet<GraphElement>();
    	
		if(this.childrenFunctionSummaries.containsKey(node)){
			HashMap<String, Object> nodeSummary = this.childrenFunctionSummaries.get(node);
	        rets = (Integer) nodeSummary.get("rets");
	        retl = (AtlasSet<GraphElement>) nodeSummary.get("retl");
	        outs = (Integer) nodeSummary.get("outs");
	        outl = (AtlasSet<GraphElement>) nodeSummary.get("outl");			
		} else if(this.lEventNodes.contains(node)){
        	rets = PathStatus.LOCK;
        	retl = new AtlasHashSet<GraphElement>();
        	outs = rets;
        	outl = this.getMyCS(node);			
		} else if(this.uEventNodes.contains(node)){
        	rets = PathStatus.UNLOCK;
        	retl = this.getMyCS(node);
        	outs = rets;
        	outl = new AtlasHashSet<GraphElement>();
		}else{
        	outs = pathStatus;
        	outl = nodeInstances;
        }
        
        boolean goon = false;
        if(this.pathToS.containsKey(node)) // visited before
        {
        	if(!this.lEventNodes.contains(node) && !this.uEventNodes.contains(node) && this.childrenFunctionSummaries.get(node) == null){
        		// Normal node
	            goon = false;
	            if(!Utils.isSubSet(outl, this.pathToL.get(node))){
	            	// new Lock on the path
	                goon = true;
	                AtlasSet<GraphElement> temp = this.pathToL.get(node);
	                temp.addAll(outl);
	                //this.pathToL.get(node).addAll(outl);
	                //Utils.debug(0, "(1)%%%%%%%%%%% PAth to Here Visited=[" + goon + "]:" + Utils.toString(path));
	               // Utils.debug(0, "outl:" + Utils.toString(outl));
	               // Utils.debug(0, "outl:" + Utils.toString(this.pathToL.get(node)));
	                
	                this.pathToL.put(node, temp);
	            }
	            if ((outs | this.pathToS.get(node)) != this.pathToS.get(node)){
	            	//in status on the path
	                goon = true;
	                this.pathToS.put(node, outs | this.pathToS.get(node));
	                //Utils.debug(0, "(2)%%%%%%%%%%% PAth to Here Visited=[" + goon + "]:" + Utils.toString(path));
	            }
	            //Utils.debug(0, "(4)%%%%%%%%%%% PAth to Here Visited=[" + goon + "]:" + Utils.toString(path));
	            if (goon){
	            	AtlasSet<GraphElement> children = Utils.getChildNodes(this.flowGraph, node);
	                if (children.size() == 0){
	                    childrens = PathStatus.THROUGH;
	                    childrenl = new AtlasHashSet<GraphElement>();
	                }else {
	                    childrens = PathStatus.UNKNOWN;
	                    childrenl = new AtlasHashSet<GraphElement>();
	                    for (GraphElement child : children){
	                    	ArrayList<GraphElement> newPath =  new ArrayList<GraphElement>(path);
	                        Object [] returns = this.traverseFlowGraph(child, outs, outl, newPath);
	                        childs = (Integer)returns[0];
	                        childl = (AtlasSet<GraphElement>) returns[1];
	                        Utils.debug(3, "RETURN: LABEL[" + child.attr().get(XCSG.name) + "] STATUS[" + PathStatus.PathStatusToText(childs) + "] SET[" + childl + "]");
	                        childrens |= childs;
	                        childrenl.addAll(childl);
	                    }
	                }
	                this.pathBackS.put(node, childrens);
	                this.pathBackL.put(node, new AtlasHashSet<GraphElement>(childrenl));
	                return new Object []{childrens, childrenl};
	            } else {
	            	//Utils.debug(0, "(5)%%%%%%%%%%% PAth to Here Visited=[" + goon + "]:" + Utils.toString(path));
	                //Utils.debug(0, "outl:" + Utils.toString(outl));
	                //Utils.debug(0, "outl:" + Utils.toString(this.pathToL.get(node)));
	            	// !goon, visited before with same information
	                if (this.pathBackS.get(node) != null)
	                    return new Object []{this.pathBackS.get(node), this.pathBackL.get(node)};
	                return new Object []{PathStatus.UNKNOWN, new AtlasHashSet<GraphElement>()};
	            }
        	}else{
       		
        		//TODO: Experimental Code below here
        		// Explanation: Imagine the case where we have a loop as in (dpm_complete) L1(x) -> U(x), but we have another path that could go to U(x) but from L2(x)
        		// The same status is coming to U(x) which is a locked object, however, we would like to visit that node because of L2(x) is in the path.
        		// The revisit Node function will check whether the currentPath has the same set of nodes in every other path visited by the same node
        		
        		if(this.reVisitNode(node)){
        			/*
	            	AtlasSet<GraphElement> children = Utils.getChildNodes(this.flowGraph, node);
	                if (children.size() == 0){
	                    childrens = PathStatus.THROUGH;
	                    childrenl = new AtlasHashSet<GraphElement>();
	                }else {
	                    childrens = PathStatus.UNKNOWN;
	                    childrenl = new AtlasHashSet<GraphElement>();
	                    for (GraphElement child : children){
	                    	ArrayList<GraphElement> newPath =  new ArrayList<GraphElement>(path);
	                        Object [] returns = this.traverseFlowGraph(child, outs, outl, newPath);
	                        childs = (Integer)returns[0];
	                        childl = (AtlasSet<GraphElement>) returns[1];
	                        Utils.debug(3, "RETURN: LABEL[" + child.attr().get(XCSG.name) + "] STATUS[" + PathStatus.PathStatusToText(childs) + "] SET[" + childl + "]");
	                        childrens |= childs;
	                        childrenl.addAll(childl);
	                    }
	                }
	                this.pathBackS.put(node, childrens);
	                this.pathBackL.put(node, new AtlasHashSet<GraphElement>(childrenl));
	                return new Object []{childrens, childrenl};
	                */
        			
        			
        			
                    this.pathToS.put(node, outs);
                    this.pathToL.put(node, new AtlasHashSet<GraphElement>(outl));
                    AtlasSet<GraphElement> children = Utils.getChildNodes(this.flowGraph, node);
                    if (children.size() == 0){
                        childrens = PathStatus.THROUGH;
                        childrenl = new AtlasHashSet<GraphElement>();
                    } else{
                        childrens = PathStatus.UNKNOWN;
                        childrenl = new AtlasHashSet<GraphElement>();
                        for(GraphElement child : children){
                        	ArrayList<GraphElement> newPath =  new ArrayList<GraphElement>(path);
                        	Object [] returns = this.traverseFlowGraph(child, outs, outl, newPath);
                        	childs = (Integer) returns[0];
                        	childl = (AtlasSet<GraphElement>) returns[1];
                        	Utils.debug(3, "RETURN: LABEL[" + child.attr().get(XCSG.name) + "] STATUS[" + PathStatus.PathStatusToText(childs) + "] SET[" + childl + "]");
                            childrens |= childs;
                            childrenl.addAll(childl);
                        }
                    }

                    if(!(this.childrenFunctionSummaries.get(node) != null) && !(this.lEventNodes.contains(node)) && !this.uEventNodes.contains(node)){
                        rets = childrens;
                        retl = new AtlasHashSet<GraphElement>(childrenl);	
                    }
                    this.pathBackS.put(node, rets);
                    this.pathBackL.put(node, new AtlasHashSet<GraphElement>(retl));
                    return new Object [] {rets, retl};
        			
        			
        		}
        		
        		// Lock or Unlock node or special node, stop here either way
        		return new Object []{rets, retl};
        	}
        } else{
        	// First visit on this path
            this.pathToS.put(node, outs);
            this.pathToL.put(node, new AtlasHashSet<GraphElement>(outl));
            AtlasSet<GraphElement> children = Utils.getChildNodes(this.flowGraph, node);
            if (children.size() == 0){
                childrens = PathStatus.THROUGH;
                childrenl = new AtlasHashSet<GraphElement>();
            } else{
                childrens = PathStatus.UNKNOWN;
                childrenl = new AtlasHashSet<GraphElement>();
                for(GraphElement child : children){
                	ArrayList<GraphElement> newPath =  new ArrayList<GraphElement>(path);
                	Object [] returns = this.traverseFlowGraph(child, outs, outl, newPath);
                	childs = (Integer) returns[0];
                	childl = (AtlasSet<GraphElement>) returns[1];
                	Utils.debug(3, "RETURN: LABEL[" + child.attr().get(XCSG.name) + "] STATUS[" + PathStatus.PathStatusToText(childs) + "] SET[" + childl + "]");
                    childrens |= childs;
                    childrenl.addAll(childl);
                }
            }

            if(!(this.childrenFunctionSummaries.get(node) != null) && !(this.lEventNodes.contains(node)) && !this.uEventNodes.contains(node)){
                rets = childrens;
                retl = new AtlasHashSet<GraphElement>(childrenl);	
            }
            this.pathBackS.put(node, rets);
            this.pathBackL.put(node, new AtlasHashSet<GraphElement>(retl));
            return new Object [] {rets, retl};
        }
    }

	private boolean reVisitNode(GraphElement node) {
		List<ArrayList<GraphElement>> myPaths = this.nodePathsMap.get(node);
		List<GraphElement> currentPath = myPaths.get(myPaths.size() - 1);
		for(int i = 0; i < myPaths.size() - 1; i++){
			if(myPaths.get(i).containsAll(currentPath)){
				return false;
			}
		}
		return true;
	}
    
    public AtlasSet<GraphElement> getMyCS(GraphElement node)
    {
    	AtlasSet<GraphElement> nodecs = new AtlasHashSet<GraphElement>();
    	if(this.childrenFunctionSummaries.get(node) == null)
    		nodecs.add(node);
    	return nodecs;
    }
	
	public HashMap<String, Object> getFunctionSummary(){
		return this.functionSummary;
	}
	
    
    /**
     * Duplicate a node in the CFG if its a called function with a summary that contains multiple statuses such as: locked and unlocked. 
     */
    public void duplicateMultipleStatusFunctions()
    {
    	for(GraphElement functionNode : this.childrenFunctionSummaries.keySet()){
    		
    		if(this.childrenFunctionSummaries.get(functionNode) == null)
    			this.childrenFunctionSummaries.put(functionNode, new HashMap<String, Object>());
    		
    		int status = (Integer) this.childrenFunctionSummaries.get(functionNode).get("rets");
    		
    		if((status | PathStatus.THROUGH) == status){
	            this.childrenFunctionSummaries.get(functionNode).put("rets", 
	            		(Integer) this.childrenFunctionSummaries.get(functionNode).get("rets") & ~PathStatus.THROUGH);
	            this.childrenFunctionSummaries.get(functionNode).put("outs", 
	            		(Integer) this.childrenFunctionSummaries.get(functionNode).get("outs") & ~PathStatus.THROUGH);
	            this.duplicateNode(functionNode);
    		}
    	}
    }
    
    private void duplicateNode(GraphElement node)
    {
    	GraphElement newNode = Graph.U.createNode(node.address());
    	newNode.tags().add(LinuxScripts.DUPLICATE_NODE);
    	
    	for(String attr : node.attr().keys()){
    		newNode.attr().put(attr, node.attr().get(attr));
    	}
    	
    	for(String tag : node.tags()){
    		newNode.tags().add(tag);
    	}
        
        for(GraphElement child : Utils.getChildNodes(this.flowGraph, node)){
        	GraphElement currentEdge = Utils.findEdge(this.flowGraph, node, child);
        	Utils.createEdge(currentEdge, newNode, child);
        }
        
        for(GraphElement parent : Utils.getParentNodes(this.flowGraph, node)){
        	GraphElement currentEdge = Utils.findEdge(this.flowGraph, parent, node);
        	Utils.createEdge(currentEdge, parent, newNode);
        }
        this.flowGraph = universe().edgesTaggedWithAny(XCSG.Contains, Queries.EVENT_FLOW_EDGE).forward(Common.toQ(Common.toGraph(this.currentFunction))).nodesTaggedWithAny(Queries.EVENT_FLOW_NODE).induce(universe().edgesTaggedWithAll(Queries.EVENT_FLOW_EDGE)).eval();
    }
}
