package com.iastate.verifier.main.deprecated;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import com.ensoftcorp.atlas.core.db.graph.Graph;
import com.ensoftcorp.atlas.core.db.graph.GraphElement;
import com.ensoftcorp.atlas.core.db.set.AtlasHashSet;
import com.ensoftcorp.atlas.core.db.set.AtlasSet;
import com.ensoftcorp.atlas.core.index.common.SourceCorrespondence;
import com.ensoftcorp.atlas.core.xcsg.XCSG;
import com.ensoftcorp.atlas.java.core.query.Q;
import com.iastate.verifier.internal.MatchingPair;
import com.iastate.verifier.internal.MultiFunctionSummaryGenerator;
import com.iastate.verifier.internal.Stater;
import com.iastate.verifier.internal.Utils;
import com.iastate.verifier.internal.deprecated.EnhancedFunctionSummaryGenerator;
import com.iastate.verifier.internal.deprecated.FunctionSummaryGenerator;
import com.iastate.verifier.internal.deprecated.StateGraph;
import com.iastate.verifier.internal.deprecated.StateNode;
import com.iastate.verifier.main.FunctionSummary;

public class VerifierTest {
	
	private String ID;
	private Graph envelope;
	private HashMap<GraphElement, Graph> functionsGraphMap;
	private HashMap<GraphElement, List<Q>> functionEventsMap;
	private HashMap<GraphElement, FunctionSummary> summaries;
	private HashMap<GraphElement, Boolean> mayEventsFeasibility;
	private HashMap<GraphElement, List<MatchingPair>> matchingPairsMap;
	
	private AtlasSet<GraphElement> e1Events;
	private AtlasSet<GraphElement> e2Events;
	private AtlasSet<GraphElement> e1MayEvents;
	
	public VerifierTest(String verificationID, Graph callGraph, HashMap<GraphElement, Graph> functionsGraphMap, HashMap<GraphElement, List<Q>> functionEventsMap, HashMap<GraphElement, Boolean> mayEventsFeasibility) {
		this.ID = verificationID;
		this.envelope = callGraph;
		this.functionsGraphMap = functionsGraphMap;
		this.functionEventsMap = functionEventsMap;
		this.summaries = new HashMap<GraphElement, FunctionSummary>();
		this.mayEventsFeasibility = mayEventsFeasibility;
		
		this.e1Events = new AtlasHashSet<GraphElement>();
		this.e1MayEvents = new AtlasHashSet<GraphElement>();
		this.e2Events = new AtlasHashSet<GraphElement>();
	}
	
	public void verify(){
		
		Utils.debug(1, "Envelope has ["+ this.envelope.nodes().size() +"] nodes.");
		
		if(!Utils.isDirectedAcyclicGraph(this.envelope)){
			Utils.error(0, "Envelope is a cyclic graph!");
			return;
		}
		
		Stater stater = new Stater();
		
		this.generateFunctionSummaries();
		
		this.matchingPairsMap = new HashMap<GraphElement, List<MatchingPair>>();
		List<GraphElement> functions = Utils.topologicalSort(this.envelope);
		for(GraphElement function : functions){
			long inDegree = Utils.getParentNodes(this.envelope, function).size();
			if(inDegree == 0){
				this.verifyFunction(function);
			}
		}
		
		stater.done();
		
		if(this.matchingPairsMap.keySet().size() != this.e1Events.size()){
			Utils.error(0, "The matching pair map contains [" + this.matchingPairsMap.size() + "] while the size of e1Events is [" + this.e1Events.size() + "]!");
		}
		stater.setE1Events(this.e1Events.size());
		stater.setE2Events(this.e2Events.size());
		
		HashSet<GraphElement> danglingE1Events = new HashSet<GraphElement>();
		HashSet<GraphElement> safeE1Events = new HashSet<GraphElement>();
		HashSet<GraphElement> doubleE1Events = new HashSet<GraphElement>();
		
		for(GraphElement e1Event : this.matchingPairsMap.keySet()){
			List<MatchingPair> pairs = this.matchingPairsMap.get(e1Event);
			for(MatchingPair pair : pairs){
				switch(pair.getResult()){
				case DANGLING_LOCK:
					danglingE1Events.add(e1Event);
					break;
				case DOUBLE_LOCK:
					doubleE1Events.add(e1Event);
					break;
				case SAFE:
					safeE1Events.add(e1Event);
					break;
				default:
					// TODO: Handle switch case
					break;
				}
			}
		}
		
		HashSet<GraphElement> verifiedE1Events = new HashSet<GraphElement>(safeE1Events);
		verifiedE1Events.removeAll(danglingE1Events);
		verifiedE1Events.removeAll(doubleE1Events);
		
		stater.setVerifiedE1Events(verifiedE1Events.size());
		for(GraphElement e1Event : verifiedE1Events){
			this.setIntraNInterProceduralCasesCount(e1Event, stater);
		}
		
		HashSet<GraphElement> partiallyVerifiedE1Events = new HashSet<GraphElement>(safeE1Events);
		partiallyVerifiedE1Events.removeAll(verifiedE1Events);
		stater.setPartiallyVerifiedE1Events(partiallyVerifiedE1Events.size());

		doubleE1Events.removeAll(partiallyVerifiedE1Events);
		stater.setRacedE1Events(doubleE1Events.size());
		
		danglingE1Events.removeAll(partiallyVerifiedE1Events);
		stater.setNotVerifiedE1Events(danglingE1Events.size());
		
		stater.printResults(this.ID);
		
		HashSet<GraphElement> alls = new HashSet<GraphElement>(this.matchingPairsMap.keySet());
		alls.removeAll(verifiedE1Events);

		Utils.debug(0, "##########################################");
		Utils.debug(0, "LEFT (e1) Events");
		Utils.debug(0, "##########################################");
		this.logViolatingPaths(alls);
		
		Utils.debug(0, "##########################################");
		Utils.debug(0, "Verified (e1) Events");
		Utils.debug(0, "##########################################");
		this.logViolatingPaths(verifiedE1Events);
		Utils.debug(0, "------------------------------------------");
		
		if(!partiallyVerifiedE1Events.isEmpty()){
			Utils.debug(0, "##########################################");
			Utils.debug(0, "Partially Verified (e1) Events");
			Utils.debug(0, "##########################################");
			this.logViolatingPaths(partiallyVerifiedE1Events);
			Utils.debug(0, "------------------------------------------");
		}
		
		if(!danglingE1Events.isEmpty()){
			Utils.debug(0, "##########################################");
			Utils.debug(0, "Dangling (Not-Verified) (e1) Events");
			Utils.debug(0, "##########################################");
			this.logViolatingPaths(danglingE1Events);
			Utils.debug(0, "------------------------------------------");
		}
		
		if(!doubleE1Events.isEmpty()){
			Utils.debug(0, "##########################################");
			Utils.debug(0, "Raced (e1) Events");
			Utils.debug(0, "##########################################");
			this.logViolatingPaths(doubleE1Events);
			Utils.debug(0, "------------------------------------------");
		}
	}

	private void logViolatingPaths(HashSet<GraphElement> e1Events) {
		for(GraphElement e1Event : e1Events){
			Utils.debug(0, "\t(e1) Event: [" + Utils.toString(e1Event) + "] in Function [" + this.getContainingFunction(e1Event).attr().get(XCSG.name) + "]");
			List<MatchingPair> pairs = this.matchingPairsMap.get(e1Event);
			int count = 0;
			for(MatchingPair pair : pairs){
				//if(!pair.getResult().equals(VerificationResult.SAFE)){
					Utils.debug(0, "\t\tMatched with Event: [" + Utils.toString(pair.getSecondEvent()) + "] in Function [" + (pair.getSecondEvent() == null ? this.getContainingFunction(e1Event).attr().get(XCSG.name) : this.getContainingFunction(pair.getSecondEvent()).attr().get(XCSG.name)) + "]");
					Utils.debug(0, "\t\tPath [" + (++count) + "] has [" + pair.getResult().name() + "]: " +  pair.getPath());
				//}
			}
		}
	}

	private void setIntraNInterProceduralCasesCount(GraphElement e1Event, Stater stater) {
		List<MatchingPair> pairs = this.matchingPairsMap.get(e1Event);
		for(MatchingPair pair : pairs){
			if(pair.getSecondEvent() != null){
				if(!this.getContainingFunction(pair.getSecondEvent()).equals(this.getContainingFunction(pair.getFirstEvent()))){
					stater.setInterproceduralVerification(stater.getInterproceduralVerification() + 1);
					return;
				}
			}
		}
		stater.setIntraproceduralVerification(stater.getIntraproceduralVerification() + 1);
	}
	
	private void verifyFunction(GraphElement function){		
		Utils.debug(2, "--------Function:" + function.attr().get(XCSG.name));
		Utils.debug(2, "Outdegree:" + Utils.getChildNodes(this.envelope, function).size());
		
		FunctionSummary summary = this.summaries.get(function);
		List<ArrayList<GraphElement>> paths = summary.getPaths();
		
		/*
		// Build the StateGraph from this function
		StateGraph stateGraph = new StateGraph(function);
		StateNode masterEntryNode = new StateNode(summary.getEntryNode());
		stateGraph.addNode(masterEntryNode);
		stateGraph.setRootNode(masterEntryNode);
		this.buildGraphFromPath(paths, summary, stateGraph, masterEntryNode);
		
	
		paths = stateGraph.getPaths();
		Utils.debug(0, stateGraph.toString());
		*/
		
		paths = this.aggregateSummaries(paths, summary);
		Utils.debug(0, "Expanded Paths Size: " + paths.size());
		
		HashMap<GraphElement, List<MatchingPair>> matchingParis = new HashMap<GraphElement, List<MatchingPair>>();
		for(GraphElement node : this.e1Events){
			matchingParis.put(node, new ArrayList<MatchingPair>());
		}
		
		for(ArrayList<GraphElement> path : paths){
			matchingParis = (HashMap<GraphElement, List<MatchingPair>>) this.verifyPath(path, (HashMap<GraphElement, List<MatchingPair>>) matchingParis.clone()).clone();
		}
		
		for(GraphElement node : matchingParis.keySet()){
			//Utils.debug(0, "##############################################");
			//Utils.debug(0, Utils.toString(node));
			List<MatchingPair> pairs = matchingParis.get(node);
			for(MatchingPair pair : pairs){
				pair.verify(this.e1Events, this.e2Events, this.summaries);
				//Utils.debug(0, pair.getPath());
			}
			List<MatchingPair> tempPairs = new ArrayList<MatchingPair>(pairs);
			if(this.matchingPairsMap.containsKey(node)){
				tempPairs.addAll(this.matchingPairsMap.get(node));
			}
			this.matchingPairsMap.put(node, tempPairs);
			//Utils.debug(0, "##############################################");
		}
	}
	
	private HashMap<GraphElement, List<MatchingPair>> verifyPath(ArrayList<GraphElement> path, HashMap<GraphElement, List<MatchingPair>> pairs){
		List<GraphElement> states = new ArrayList<GraphElement>();
		for(GraphElement node : path){
			//Utils.debug(0, "Path to mine for Matching Pairs:\t" + toString(path));
			if(this.e1Events.contains(node) && !this.e1MayEvents.contains(node)){
				states.add(node);
			}else if(this.e1MayEvents.contains(node)){
				boolean lockOnTrueBranch = this.mayEventsFeasibility.get(node);
				GraphElement containingFunction = this.getContainingFunction(node);
				FunctionSummary s = this.summaries.get(containingFunction);
				GraphElement nextElement = path.get(path.indexOf(node) + 1);

				ArrayList<GraphElement> p = this.getPathContainingNode(node, s, nextElement);
				
				nextElement = p.get(p.indexOf(node) + 1);
				
				GraphElement edge = Utils.findEdge(s.getFeasibilityChecker().getFunctionCFG(), node, nextElement);
				String conditionValue = ((String) edge.attr().get(XCSG.conditionValue)).toLowerCase();
				//Utils.debug(0, "$$$$$$$$$$$$$$:\t" + node.attr().get(XCSG.name) + "\t" +  conditionValue + "\t" + lockOnTrueBranch);
				if(conditionValue.equals("true") && lockOnTrueBranch){
						states.add(node);						
				}else if(conditionValue.equals("false") && !lockOnTrueBranch){
						states.add(node);							
				}else{
					//TODO: Handle other cases specially (switch) statements
				}
			}else if(this.e2Events.contains(node)){
				states.add(node);
			}
		}
		
		for(int i = 0; i < states.size(); i++){
			//Utils.debug(0, "%%%%%%%%%" + toString(states));
			GraphElement node = states.get(i);
			if(pairs.containsKey(node)){
				ArrayList<MatchingPair> ps = new ArrayList<MatchingPair>(pairs.get(node));
				GraphElement nextNode = null;
				if(i + 1 < states.size()){
					nextNode = states.get(i+1);
				}
				//Utils.debug(0, "Adding Matching Pair:\t" + Utils.toString(node) + "\t" +  Utils.toString(nextNode));
				MatchingPair pair = new MatchingPair(node, nextNode, path);
				ps.add(pair);
				pairs.put(node, ps);
			}
		}
		return pairs;
	}

	private ArrayList<GraphElement> getPathContainingNode(GraphElement node, FunctionSummary s, GraphElement nextElement) {
		List<ArrayList<GraphElement>> pathsContiningNodes = null;
		if(s.getExitNode().equals(nextElement)){
			pathsContiningNodes = s.getFeasibilityChecker().getPathsContainingNode(node);
			if(pathsContiningNodes.size() == 1 || !node.tags().contains(XCSG.ControlFlowCondition)){
				return pathsContiningNodes.get(0);
			}else{
				//Utils.debug(0, "%%%%%%%%%[" + pathsContiningNodes.size() + "]" + toString(path));
				// If its a condition, then we need to get the paths containing the node correctly
				// For example: if we have a (mutex_trylock) T-> (EXIT Node)
				//                           (mutex_trylock) F-> (Event Node) -> (Exit Node)
				HashMap<Integer, ArrayList<GraphElement>> pathIDs = new HashMap<Integer, ArrayList<GraphElement>>();
				for(ArrayList<GraphElement> returnedPath : pathsContiningNodes){
					List<GraphElement> subList = returnedPath.subList(returnedPath.indexOf(node) + 1, returnedPath.size());
					pathIDs.put(subList.size(), returnedPath);
				}
				List<Integer> temp = new ArrayList<Integer>(pathIDs.keySet());
				Collections.sort(temp);
				for(Integer t : temp){
					ArrayList<GraphElement> returnedPath = pathIDs.get(t);
					List<GraphElement> subList = returnedPath.subList(returnedPath.indexOf(node) + 1, returnedPath.size());
					//Utils.debug(0, "%%%%%%%%%SUBLIST:" + toString(subList));
					boolean containsEvents = false;
					for(GraphElement n : subList){
						if(this.e1Events.contains(n) || this.e2Events.contains(n) || this.mayEventsFeasibility.containsKey(n)){
							containsEvents = true;
							break;
						}
					}
					if(!containsEvents){
						//p = returnedPath;
						//Utils.debug(0, "%%%%%%%%%" + toString(path));
						return returnedPath;
					}
				}
			}
		}
		pathsContiningNodes = s.getFeasibilityChecker().getPathsContainingNodes(node, nextElement);
		return pathsContiningNodes.get(0);
	}
	
	private void buildGraphFromPath(List<ArrayList<GraphElement>> paths, FunctionSummary summary, StateGraph stateGraph, StateNode masterEntry){
		for(ArrayList<GraphElement> path : paths){
			//Utils.debug(0, "Path:" + Utils.toString(path));
			StateNode parentNode = null;
			for(GraphElement node : path){
				StateNode currentNode = new StateNode(node);
				if(this.mayEventsFeasibility.containsKey(node)){
					stateGraph.addNode(currentNode);
					stateGraph.addEdge(parentNode == null ? masterEntry : parentNode, currentNode);
					parentNode = currentNode;
				}else if(summary.getCallEvents().contains(node)){
					//Utils.debug(0, "Summary For function:" + Utils.toString(summary.getFunction()));
					//Utils.debug(0, "Node:" + Utils.toString(node));
					//Utils.debug(0, "Number foa mappings:" + summary.getCallEventsFunctionsMap().size());
					//Utils.debug(0, "Number foa String:" + Utils.toString(summary.getFunctionElementForCallEvent(node)));
					FunctionSummary newSummary = this.summaries.get(summary.getFunctionElementForCallEvent(node));
					buildGraphFromPath(newSummary.getPaths(), newSummary, stateGraph, parentNode == null ? masterEntry : parentNode);
					parentNode = new StateNode(newSummary.getExitNode());
					stateGraph.addNode(parentNode);
				}else{
					stateGraph.addNode(currentNode);
					if(!(parentNode == null && masterEntry.equals(currentNode)))
						stateGraph.addEdge(parentNode == null ? masterEntry : parentNode, currentNode);
					parentNode = currentNode;
				}
			}
		}
	}
	
	private List<ArrayList<GraphElement>> aggregateSummaries(List<ArrayList<GraphElement>> paths, FunctionSummary summary){
		List<ArrayList<GraphElement>> newPaths = new ArrayList<ArrayList<GraphElement>>();
		for(ArrayList<GraphElement> path : paths){
			List<ArrayList<GraphElement>> newPath = new ArrayList<ArrayList<GraphElement>>();
			newPath.add(new ArrayList<GraphElement>());
			for(GraphElement node : path){
				if(!this.mayEventsFeasibility.containsKey(node) && summary.getCallEvents().contains(node)){
					FunctionSummary newSummary = this.summaries.get(summary.getFunctionElementForCallEvent(node));
					List<ArrayList<GraphElement>> calledFunctionPaths = this.aggregateSummaries(newSummary.getPaths(), newSummary);
					List<ArrayList<GraphElement>> expandedPaths = new ArrayList<ArrayList<GraphElement>>();
					for(ArrayList<GraphElement> calledFunctionPath : calledFunctionPaths){
						for(ArrayList<GraphElement> currentPath : newPath){
							ArrayList<GraphElement> expandedPath = new ArrayList<GraphElement>(currentPath);
							expandedPath.addAll(calledFunctionPath);
							expandedPaths.add(expandedPath);
						}
					}
					newPath = new ArrayList<ArrayList<GraphElement>>(expandedPaths);
					
				}else{
					for(ArrayList<GraphElement> currentPath : newPath){
						currentPath.add(node);
					}
				}
			}
			newPaths.addAll(newPath);
		}
		return newPaths;
	}
	


	private void generateFunctionSummaries(){

		HashMap<GraphElement, HashMap<String, Object>> functionSummaries = new HashMap<GraphElement, HashMap<String,Object>>();
		
		List<GraphElement> functions = Utils.topologicalSort(this.envelope);
		Collections.reverse(functions);
		
		for(GraphElement function : functions){
			//Utils.debug(2, "Generating Summary For Function:" + function.attr().get(XCSG.name));
			//this.summaries.put(function, this.getFunctionSummary(function, functionSummaries));
			this.summaries.put(function, this.getMultiFunctionSummary(function, functionSummaries));
			//this.summaries.put(function, this.getEnhancedFunctionSummary(function, functionSummaries));
			Utils.debug(0, this.summaries.get(function).toString());
		}
	}
	
	private FunctionSummary getEnhancedFunctionSummary(GraphElement function, HashMap<GraphElement, HashMap<String, Object>> functionSummaries){
		Graph flowGraph = this.functionsGraphMap.get(function);
		List<Q> events = this.functionEventsMap.get(function);
		EnhancedFunctionSummaryGenerator summaryGenerator = new EnhancedFunctionSummaryGenerator(function, flowGraph, Utils.getChildNodes(this.envelope, function));	
		FunctionSummary summary = summaryGenerator.run(events);
		
		this.e1Events.addAll(summary.getE1Events());
		this.e1MayEvents.addAll(summary.getE1MayEvents());
		this.e2Events.addAll(summary.getE2Events());
		
		return summary;
	}
	
	private FunctionSummary getFunctionSummary(GraphElement function, HashMap<GraphElement, HashMap<String, Object>> functionSummaries){
		Graph flowGraph = this.functionsGraphMap.get(function);
		List<Q> events = this.functionEventsMap.get(function);
		HashMap<GraphElement, HashMap<String, Object>> childrenFunctionSummaries = this.getChildrenFunctionSummaries(function, functionSummaries);
		
		FunctionSummaryGenerator summaryGenerator = new FunctionSummaryGenerator(function, flowGraph, childrenFunctionSummaries);	
		FunctionSummary summary = summaryGenerator.run(events);
		functionSummaries.put(function, summaryGenerator.getFunctionSummary());
		
		this.e1Events.addAll(summary.getE1Events());
		this.e1MayEvents.addAll(summary.getE1MayEvents());
		this.e2Events.addAll(summary.getE2Events());
		
		return summary;
	}
	
	private FunctionSummary getMultiFunctionSummary(GraphElement function, HashMap<GraphElement, HashMap<String, Object>> functionSummaries){
		Graph flowGraph = this.functionsGraphMap.get(function);
		List<Q> events = this.functionEventsMap.get(function);
		HashMap<GraphElement, HashMap<String, Object>> childrenFunctionSummaries = this.getChildrenFunctionSummaries(function, functionSummaries);
		
		MultiFunctionSummaryGenerator summaryGenerator = new MultiFunctionSummaryGenerator(function, flowGraph, childrenFunctionSummaries);	
		FunctionSummary summary = summaryGenerator.run(events);
		functionSummaries.put(function, summaryGenerator.getFunctionSummary());
		
		this.e1Events.addAll(summary.getE1Events());
		this.e1MayEvents.addAll(summary.getE1MayEvents());
		this.e2Events.addAll(summary.getE2Events());
		
		return summary;
	}
	
	private HashMap<GraphElement, HashMap<String, Object>> getChildrenFunctionSummaries(GraphElement function, HashMap<GraphElement, HashMap<String, Object>> functionSummaries){
		HashMap<GraphElement, HashMap<String, Object>> childrenFunctionSummaries = new HashMap<GraphElement, HashMap<String,Object>>();
		
		AtlasSet<GraphElement> children = Utils.getChildNodes(this.envelope, function);

		for(GraphElement child : children)
			childrenFunctionSummaries.put(child, (HashMap<String, Object>) functionSummaries.get(child).clone());
		
		return childrenFunctionSummaries;	
	}
	
	private GraphElement getContainingFunction(GraphElement node){
		for(GraphElement function : this.summaries.keySet()){
			if(this.summaries.get(function).getFlowGraph().nodes().contains(node))
				return function;
		}
		return null;
	}
}
