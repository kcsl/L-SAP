package com.iastate.atlas.scripts;

import static com.ensoftcorp.atlas.core.script.Common.resolve;
import static com.ensoftcorp.atlas.core.script.Common.toGraph;
import static com.ensoftcorp.atlas.core.script.Common.toQ;
import static com.ensoftcorp.atlas.core.script.Common.universe;

import java.util.HashMap;
import java.util.Map;

import atlas.c.scripts.Queries;

import com.ensoftcorp.atlas.core.db.graph.EdgeGraph;
import com.ensoftcorp.atlas.core.db.graph.Graph;
import com.ensoftcorp.atlas.core.db.graph.GraphElement;
import com.ensoftcorp.atlas.core.db.graph.GraphElement.EdgeDirection;
import com.ensoftcorp.atlas.core.db.graph.GraphElement.NodeDirection;
import com.ensoftcorp.atlas.core.db.set.AtlasHashSet;
import com.ensoftcorp.atlas.core.db.set.AtlasSet;
import com.ensoftcorp.atlas.core.db.set.IntersectionSet;
import com.ensoftcorp.atlas.core.db.set.SingletonAtlasSet;
import com.ensoftcorp.atlas.core.highlight.Highlighter;
import com.ensoftcorp.atlas.core.query.Q;
import com.ensoftcorp.atlas.core.xcsg.XCSG;
import com.ensoftcorp.atlas.java.core.script.Common;
import com.ensoftcorp.atlas.ui.viewer.graph.DisplayUtil;
import com.iastate.verifier.internal.Utils;

public class Loop {

	public static Q loopbackEdges(){
		Q u = universe();
		Q cfContext = resolve(null, u.edgesTaggedWithAny(XCSG.ControlFlow_Edge));
		
		AtlasSet<GraphElement> loopbacks = new AtlasHashSet<GraphElement>((int) cfContext.eval().edges().size());
		Map<GraphElement, AtlasSet<GraphElement>> dominatorTree = new HashMap<GraphElement, AtlasSet<GraphElement>>();
		Map<GraphElement, AtlasSet<GraphElement>[]> predecessorDominators = new HashMap<GraphElement, AtlasSet<GraphElement>[]>(); 
		
		int count = 0;
		// Compute individually on a per-function basis
		for(GraphElement function : u.nodesTaggedWithAll(XCSG.Function, "isDef").eval().nodes()){
			if(!function.hasAttr(XCSG.name)){
				continue;
			}
			// Control flow nodes in the function
			Graph CFG = Queries.CFG(toQ(toGraph(function))).eval();
			AtlasSet<GraphElement> cfn = new AtlasHashSet<GraphElement>(CFG.nodes());
			if(cfn.size() == 0) continue;
			if(isGraphDisconnected(CFG)){
				continue;
			}
			Utils.debug(0, (++count) + "-" + function.getAttr(XCSG.name).toString());
			// Compute the dominator tree for the function
			dominatorTree.clear();
			predecessorDominators.clear();
			GraphElement cfRoot = cfn.taggedWithAny(XCSG.controlFlowRoot).getFirst();
			// Root dominates itself
			dominatorTree.put(cfRoot, new SingletonAtlasSet<GraphElement>(cfRoot));
			for(GraphElement cfNode : cfn){
				if(cfNode == cfRoot) continue;
				// Let non-roots initially be dominated by everything
				dominatorTree.put(cfNode, new AtlasHashSet<GraphElement>(cfn));
			}
			// Pre-cache predecessor dominator arrays
			for(GraphElement cfNode : cfn){
				if(cfNode == cfRoot) continue;
				AtlasSet<GraphElement> predecessors = cfContext.predecessors(toQ(toGraph(cfNode))).eval().nodes();
				@SuppressWarnings("unchecked")
				AtlasSet<GraphElement>[] predecessorDominatorArray = new AtlasSet[(int) predecessors.size()];
				int idx = 0;
				for(GraphElement ge : predecessors) predecessorDominatorArray[idx++] = dominatorTree.get(ge);
				predecessorDominators.put(cfNode, predecessorDominatorArray);
			}
			// Iteratively eliminate nodes that are not dominators from dominator sets
			boolean changed = true;
			while(changed){
				changed = false;
				for(GraphElement cfNode : cfn){
					if(cfNode == cfRoot) continue;
					AtlasSet<GraphElement>[] predecessorDominatorArray = predecessorDominators.get(cfNode);
					AtlasSet<GraphElement> predecessorCommonDominators = predecessorDominatorArray.length > 1 ? 
							new IntersectionSet<GraphElement>(predecessorDominators.get(cfNode)) : predecessorDominatorArray[0];
					
					// Remove dominators that are not cfNode or in the intersection of predecessor dominators
					AtlasSet<GraphElement> dominators = dominatorTree.get(cfNode);
					if(dominators.size() > predecessorCommonDominators.size() + 1){
						changed = true;
						dominators.clear();
						dominators.add(cfNode);
						dominators.addAll(predecessorCommonDominators);
					}
				}
			}

			// Identify dominator tree back edges
			Graph cfContextG = cfContext.eval();
			for(GraphElement cfNode : cfn){
				AtlasSet<GraphElement> dominators = dominatorTree.get(cfNode);
				for(GraphElement cfEdge : cfContextG.edges(cfNode, NodeDirection.OUT)){
					GraphElement dest = cfEdge.getNode(EdgeDirection.TO);
					
					// Edge is a loopback edge iff this node is transitively dominated by dest
					if(dominators.contains(dest)){
						loopbacks.add(cfEdge);
					}
				}
			}
		}
		
		return toQ(new EdgeGraph(loopbacks));
	}
	
	private static boolean isGraphDisconnected(Graph g){
		for(GraphElement node : g.nodes()){
			if(Utils.getChildNodes(g, node).isEmpty() && Utils.getParentNodes(g, node).isEmpty()){
				return true;
			}
		}
		return false;
	}
	
	public static Q test(String functionName){
		Q function = Queries.function(functionName);
		Q cfgQ = Queries.CFG(function);
		DisplayUtil.displayGraph(Common.extend(cfgQ, XCSG.Contains).eval(), new Highlighter(), "CFG-" + functionName);
		Graph cfg = cfgQ.eval();
		GraphElement entryNode = cfg.nodes().taggedWithAll(XCSG.controlFlowRoot).getFirst();
		identify_loops(cfg, entryNode);
		
		for(GraphElement node : loop_header_Map.keySet()){
			if(loop_header_Map.get(node)){
				DisplayUtil.displayGraph(toGraph(node), new Highlighter(), "Loop Header");
			}
		}
		
		for(GraphElement node : irreducible_loop_map.keySet()){
			if(irreducible_loop_map.get(node)){
				DisplayUtil.displayGraph(toGraph(node), new Highlighter(), "Irreducible Loop");
			}
		}
		return Common.empty();
	}
	
	public static HashMap<GraphElement, Boolean> traversed_Map = new HashMap<GraphElement, Boolean>();
	public static HashMap<GraphElement, Boolean> loop_header_Map = new HashMap<GraphElement, Boolean>();
	public static HashMap<GraphElement, Boolean> reentry_node_Map = new HashMap<GraphElement, Boolean>();
	public static HashMap<GraphElement, Boolean> reentry_edge_Map = new HashMap<GraphElement, Boolean>();
	public static HashMap<GraphElement, Boolean> irreducible_loop_map = new HashMap<GraphElement, Boolean>();
	public static HashMap<GraphElement, Integer> DFSP_pos_Map = new HashMap<GraphElement, Integer>();
	public static HashMap<GraphElement, GraphElement> iloop_header = new HashMap<GraphElement, GraphElement>();
	
	private static void identify_loops(Graph cfg, GraphElement h0){
		for(GraphElement node : cfg.nodes()){
			//initialize(node);
			traversed_Map.put(node, false);
			DFSP_pos_Map.put(node, 0);
			loop_header_Map.put(node, false);
			reentry_node_Map.put(node, false);
			iloop_header.put(node, null);
		}
		trav_loops_DFS(cfg, h0, 1);
	}
	
	private static GraphElement trav_loops_DFS(Graph cfg, GraphElement b0, int DFSP_pos){
		traversed_Map.put(b0, true);
		DFSP_pos_Map.put(b0, DFSP_pos);
		AtlasSet<GraphElement> succ_b0 = Utils.getChildNodes(cfg, b0);
		for(GraphElement b : succ_b0){
			if(!traversed_Map.get(b)){
				// case(A), new
				GraphElement nh = trav_loops_DFS(cfg, b, DFSP_pos + 1);
				tag_lhead(b0, nh);
			}else{
				if(DFSP_pos_Map.get(b) > 0){
					// case(B)
					loop_header_Map.put(b, true);
					tag_lhead(b0, b);
				}else if(iloop_header.get(b) == null){
					// case(C), do nothing
					;
				}else{
					GraphElement h = iloop_header.get(b);
					if(DFSP_pos_Map.get(h) > 0){
						// case(D)
						tag_lhead(b0, h);
					}else{
						// case(E), reentry
						reentry_node_Map.put(b, true);
						GraphElement b0_b_edge = Utils.findEdge(cfg, b0, b);
						if(b0_b_edge != null){
							reentry_edge_Map.put(b0_b_edge, true);
						}
						irreducible_loop_map.put(h, true);
						while(iloop_header.get(h) != null){
							h = iloop_header.get(h);
							if(DFSP_pos_Map.get(h) > 0){
								tag_lhead(b0, h);
								break;
							}
							irreducible_loop_map.put(h, true);
						}
					}
				}
			}
		}
		DFSP_pos_Map.put(b0, 0);
		return iloop_header.get(b0);
	}
	
	private static void tag_lhead(GraphElement b, GraphElement h){
		if(b.equals(h) || h == null){
			return;
		}
		GraphElement cur1 = b;
		GraphElement cur2 = h;
		while(iloop_header.get(cur1) != null){
			GraphElement ih = iloop_header.get(cur1);
			if(ih.equals(cur2)){
				return;
			}
			if(DFSP_pos_Map.get(ih) < DFSP_pos_Map.get(cur2)){
				iloop_header.put(cur1, cur2);
				cur1 = cur2;
				cur2 = ih;
			}else{
				cur1 = ih;
			}
		}
		iloop_header.put(cur1, cur2);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}