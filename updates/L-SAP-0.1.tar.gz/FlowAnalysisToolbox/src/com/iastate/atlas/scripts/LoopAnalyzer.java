package com.iastate.atlas.scripts;

import static com.ensoftcorp.atlas.core.script.Common.resolve;
import static com.ensoftcorp.atlas.core.script.Common.toGraph;
import static com.ensoftcorp.atlas.core.script.Common.toQ;
import static com.ensoftcorp.atlas.core.script.Common.universe;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import atlas.c.scripts.Queries;

import com.ensoftcorp.atlas.core.db.graph.EdgeGraph;
import com.ensoftcorp.atlas.core.db.graph.Graph;
import com.ensoftcorp.atlas.core.db.graph.GraphElement;
import com.ensoftcorp.atlas.core.db.graph.GraphElement.EdgeDirection;
import com.ensoftcorp.atlas.core.db.graph.GraphElement.NodeDirection;
import com.ensoftcorp.atlas.core.db.set.AtlasHashSet;
import com.ensoftcorp.atlas.core.db.set.AtlasSet;
import com.ensoftcorp.atlas.core.db.set.IntersectionSet;
import com.ensoftcorp.atlas.core.db.set.SingletonAtlasSet;
import com.ensoftcorp.atlas.core.query.Q;
import com.ensoftcorp.atlas.core.xcsg.XCSG;
import com.iastate.verifier.internal.Utils;

/**
 * Uses algorithm from Wei et al. to identify loops, even irreducible ones.
 * http://www.lenx.100871.net/papers/loop-SAS.pdf
 * 
 * @author tdeering
 *
 */
public class LoopAnalyzer {
	public static interface CFGNode{
		/**
		 * Tag applied to loop header CFG node
		 */
		public static final String LOOP_HEADER = "LOOP_HEADER";
		
		/**
		 * Tag applied to loop reentry CFG node
		 */
		public static final String LOOP_REENTRY_NODE = "LOOP_REENTRY_NODE";
		
		/**
		 * Tag applied to irreducible loop headers
		 */
		public static final String IRREDUCIBLE_LOOP = "IRREDUCIBLE_LOOP";
		
		/**
		 * Tag applied to natural loop headers
		 */
		public static final String NATURAL_LOOP = "NATURAL_LOOP";
		
		/**
		 * Integer attribute identifing the innermost loop fragment in which
		 * this CFG node participates
		 */
		public static final String INNERMOST_LOOP_ID = "INNERMOST_LOOP_ID";
	}

	public static interface CFGEdge{
		/**
		 * Tag for ControlFlow_Edge indicating a loop reentry
		 */
		public static final String LOOP_REENTRY_EDGE = "LOOP_REENTRY_EDGE";
	}
	
	/**
	 * Identify all loop fragments, headers, re-entries, and nesting in the universe 
	 * graph, applying the tags and attributes in interfaces CFGNode and CFGEdge.
	 * 
	 * NOTE: Handles both natural and irreducible loops
	 * 
	 * @return
	 */
	public static void analyzeLoops(){
		new LoopAnalyzer().analyzeAllLoops();
	}
	
	/**
	 * Use a dominator-tree analysis to identify loopback edges in the CFG.
	 * Returns all loopback ControlFlow_Edges.
	 * 
	 * NOTE: Handles only natural loops
	 * 
	 * @return
	 */
	public static Q dominanceLoopbacks(){
		Q u = universe();
		Q cfContext = resolve(null, u.edgesTaggedWithAny(XCSG.ControlFlow_Edge));
		Q hasCFContext = resolve(null, u.edgesTaggedWithAny(XCSG.HasControlFlow));
		
		AtlasSet<GraphElement> loopbacks = new AtlasHashSet<GraphElement>((int) cfContext.eval().edges().size());
		Map<GraphElement, AtlasSet<GraphElement>> dominatorTree = new HashMap<GraphElement, AtlasSet<GraphElement>>();
		Map<GraphElement, AtlasSet<GraphElement>[]> predecessorDominators = new HashMap<GraphElement, AtlasSet<GraphElement>[]>(); 
		
		// Compute individually on a per-function basis
		for(GraphElement function : u.nodesTaggedWithAny(XCSG.Function).eval().nodes()){
			// Control flow nodes in the function
			AtlasSet<GraphElement> cfn = new AtlasHashSet<GraphElement>(hasCFContext.successors(toQ(toGraph(function))).eval().nodes());
			if(cfn.size() == 0) continue;
			
			// Compute the dominator tree for the function
			dominatorTree.clear();
			predecessorDominators.clear();
			GraphElement cfRoot = cfn.taggedWithAny(XCSG.controlFlowRoot).getFirst();
			// Root dominates itself
			dominatorTree.put(cfRoot, new SingletonAtlasSet<GraphElement>(cfRoot));
			for(GraphElement cfNode : cfn){
				if(cfNode == cfRoot) continue;
				// Let non-roots initially be dominated by everything
				dominatorTree.put(cfNode, new AtlasHashSet<GraphElement>(cfn));
			}
			// Pre-cache predecessor dominator arrays
			for(GraphElement cfNode : cfn){
				if(cfNode == cfRoot) continue;
				AtlasSet<GraphElement> predecessors = cfContext.predecessors(toQ(toGraph(cfNode))).eval().nodes();
				@SuppressWarnings("unchecked")
				AtlasSet<GraphElement>[] predecessorDominatorArray = new AtlasSet[(int) predecessors.size()];
				int idx = 0;
				for(GraphElement ge : predecessors) predecessorDominatorArray[idx++] = dominatorTree.get(ge);
				predecessorDominators.put(cfNode, predecessorDominatorArray);
			}
			// Iteratively eliminate nodes that are not dominators from dominator sets
			boolean changed = true;
			while(changed){
				changed = false;
				for(GraphElement cfNode : cfn){
					if(cfNode == cfRoot) continue;
					AtlasSet<GraphElement>[] predecessorDominatorArray = predecessorDominators.get(cfNode);
					AtlasSet<GraphElement> predecessorCommonDominators = predecessorDominatorArray.length > 1 ? 
							new IntersectionSet<GraphElement>(predecessorDominators.get(cfNode)) : predecessorDominatorArray[0];
					
					// Remove dominators that are not cfNode or in the intersection of predecessor dominators
					AtlasSet<GraphElement> dominators = dominatorTree.get(cfNode);
					if(dominators.size() > predecessorCommonDominators.size() + 1){
						changed = true;
						dominators.clear();
						dominators.add(cfNode);
						dominators.addAll(predecessorCommonDominators);
					}
				}
			}

			// Identify dominator tree back edges
			Graph cfContextG = cfContext.eval();
			for(GraphElement cfNode : cfn){
				AtlasSet<GraphElement> dominators = dominatorTree.get(cfNode);
				for(GraphElement cfEdge : cfContextG.edges(cfNode, NodeDirection.OUT)){
					GraphElement dest = cfEdge.getNode(EdgeDirection.TO);
					
					// Edge is a loopback edge iff this node is transitively dominated by dest
					if(dominators.contains(dest)){
						loopbacks.add(cfEdge);
					}
				}
			}
		}
		
		return toQ(new EdgeGraph(loopbacks));
	}
	
	private AtlasSet<GraphElement> traversed, loopHeaders, reentryNodes, reentryEdges, irreducible;
	private Q u;
	private Map<GraphElement, Integer> dsfp;
	private Map<GraphElement, GraphElement> innermostLoopHeaders;
	
	private LoopAnalyzer(){
		u = universe();
		traversed = new AtlasHashSet<GraphElement>();
		loopHeaders = new AtlasHashSet<GraphElement>();
		reentryNodes = new AtlasHashSet<GraphElement>();
		reentryEdges = new AtlasHashSet<GraphElement>();
		irreducible = new AtlasHashSet<GraphElement>();
		dsfp = new HashMap<GraphElement, Integer>();
		innermostLoopHeaders = new HashMap<GraphElement, GraphElement>();
	}
	
	private static boolean isGraphDisconnected(Graph g){
		for(GraphElement node : g.nodes()){
			if(Utils.getChildNodes(g, node).isEmpty() && Utils.getParentNodes(g, node).isEmpty()){
				return true;
			}
		}
		return false;
	}
	
	private void analyzeAllLoops(){
		int count = 0;
		// Compute individually on a per-function basis
		HashSet<String> functionNames = new HashSet<String>(); 
		for(GraphElement function : u.nodesTaggedWithAll(XCSG.Function, "isDef").eval().nodes()){
			
			if(!function.hasAttr(XCSG.name)){
				continue;
			}
			
			String functionName = function.getAttr(XCSG.name).toString();
			if(functionNames.contains(functionName)){
				continue;
			}else{
				functionNames.add(functionName);
			}
			
			List<String> problematicFunctions = new ArrayList<String>();
			problematicFunctions.add("parse_weakpages");
			problematicFunctions.add("lustre_assert_wire_constants");
			problematicFunctions.add("ata_acpi_bind_port");
			problematicFunctions.add("ata_acpi_set_state");
			problematicFunctions.add("fls");
			problematicFunctions.add("erase_error");
			problematicFunctions.add("mutex_lock_interruptible_nested");
			problematicFunctions.add("lpphy_read_tx_pctl_mode_from_hardware");
			problematicFunctions.add("rtl8192_rx_cmd");
			problematicFunctions.add("ata_acpi_on_devcfg");
			problematicFunctions.add("ata_acpi_on_resume");
			problematicFunctions.add("query_rx_cmdpkt_desc_status");
			problematicFunctions.add("free_nandsim");
			problematicFunctions.add("ata_acpi_dissociate");
			problematicFunctions.add("trace_iwlwifi_dev_iowrite_prph32");
			problematicFunctions.add("cmos_write_bank2");
			problematicFunctions.add("bnx2x_mstat_stats_update");
			problematicFunctions.add("parse_badblocks");
			problematicFunctions.add("rtllib_associate_step2");
			problematicFunctions.add("ade7854_write_8bit");
			if(problematicFunctions.contains(functionName)){
				continue;
			}
			
			// Clear data from previous function
			traversed.clear();
			dsfp.clear();
			Q functionQ = toQ(toGraph(function));
			Q cfgQ = Queries.CFG(functionQ);
			
			AtlasSet<GraphElement> cfgNodes = cfgQ.eval().nodes();
			if(cfgNodes.isEmpty()) continue;
			if(isGraphDisconnected(cfgQ.eval())){
				continue;
			}
			Utils.debug(0, (++count) + "-" + function.getAttr(XCSG.name).toString());
			
			GraphElement root = null;
			for(GraphElement ge : cfgNodes){
				dsfp.put(ge, 0);
				if(ge.taggedWith(XCSG.controlFlowRoot)) root = ge;
			}
			
			// Loop identification algorithm
			loopDFS(cfgQ.eval(), root, 1);
		}

		// Modify universe graph 
		Collection<GraphElement> loopHeaders = innermostLoopHeaders.values();
		Map<GraphElement, Integer> loopHeaderToID = new HashMap<GraphElement, Integer>(loopHeaders.size());
		int idGenerator = 0;
		for(GraphElement header : loopHeaders){
			loopHeaderToID.put(header, idGenerator++);
			header.tag(CFGNode.LOOP_HEADER);
			header.putAttr(CFGNode.INNERMOST_LOOP_ID, loopHeaderToID.get(header));
			if(irreducible.contains(header)){
				header.tag(CFGNode.IRREDUCIBLE_LOOP);
			}else{
				header.tag(CFGNode.NATURAL_LOOP);
			}
		}
		

		for(GraphElement cfgNode : innermostLoopHeaders.keySet()){
			if(!loopHeaders.contains(cfgNode)){
				cfgNode.putAttr(CFGNode.INNERMOST_LOOP_ID, loopHeaderToID.get(innermostLoopHeaders.get(cfgNode)));
			}
		}
		
		for(GraphElement reentryNode : reentryNodes){
			reentryNode.tag(CFGNode.LOOP_REENTRY_NODE);
		}
		
		for(GraphElement reentryEdge : reentryEdges){
			reentryEdge.tag(CFGEdge.LOOP_REENTRY_EDGE);
		}
	}
	
	/**
	 * Recursively traverse the current node, returning its innermost loop header
	 * @param b0
	 * @param position
	 * @return
	 */
	private void loopDFS(Graph cfg, GraphElement b0, int position){
		traversed.add(b0);
		dsfp.put(b0, position);
		
		for(GraphElement cfgEdge : cfg.edges(b0, NodeDirection.OUT)){
			GraphElement b = cfgEdge.getNode(EdgeDirection.TO);
			
			if(!traversed.contains(b)){
				// Paper Case A
				loopDFS(cfg, b, position + 1);
				GraphElement nh = innermostLoopHeaders.get(b);
				tag_lhead(b0, nh);
			}
			else{
				// Paper Case B
				if(dsfp.get(b) > 0){
					loopHeaders.add(b);
					tag_lhead(b0, b);
				}else{
					GraphElement h = innermostLoopHeaders.get(b);
					// Paper Case C
					if(h == null) continue;
					
					// Paper Case D
					if(dsfp.get(h) > 0){
						tag_lhead(b0, h);
					}
					// Paper Case E
					else{
						reentryNodes.add(b);
						reentryEdges.add(cfgEdge);
						irreducible.add(h);
						
						while((h = innermostLoopHeaders.get(h)) != null){
							if(dsfp.get(h) > 0){
								tag_lhead(b0, h);
								break;
							}
							irreducible.add(h);
						}
					}	
				}
			}
		}
		
		dsfp.put(b0, 0);
	}
	
	private void tag_lhead(GraphElement b, GraphElement h){
		if(b == h || h == null) return;
		GraphElement cur1 = b;
		GraphElement cur2 = h;
		
		GraphElement ih;
		while((ih = innermostLoopHeaders.get(cur1)) != null){
			if(ih == cur2) return;
			if(dsfp.get(ih) < dsfp.get(cur2)){
				innermostLoopHeaders.put(cur1, cur2);
				cur1 = cur2;
				cur2 = ih;
			}else{
				cur1 = ih;
			}
		}
		innermostLoopHeaders.put(cur1, cur2);
	}
}